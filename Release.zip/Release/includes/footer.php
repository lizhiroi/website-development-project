
</main>
    <!-- main-area-end -->


    <!-- FOOTER -->
    <!-- footer-area -->
    <footer>
        <div class="footer-area footer-bg">
            <div class="footer-top">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-3 col-lg-4 col-md-6">
                            <div class="footer-widget">
                                <div class="footer-logo">
                                    <a href="homepage.html"><img class="img-responsive" width="100px" height="" src="assets/img/favicon.png" alt=""></a>
                                </div>
                                <div class="footer-content">
                                    <p>Online to make your journey even more memorable access or meet</p>

                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-4 col-md-6">
                            <div class="footer-widget">
                                <div class="fw-title">
                                    <h4 class="title">Explore</h4>
                                </div>
                                <div class="fw-link">
                                    <ul>
                                        <li><a href="about.html">About us</a></li>
                                        <li><a href="contact.html">Travel alerts</a></li>
                                        <li><a href="contact.html">Awards</a></li>

                                        <li><a href="contact.html">Careers</a></li>

                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-4 col-sm-4">
                            <div class="footer-widget privacy">
                                <div class="fw-title">
                                    <h4 class="title">Privacy</h4>
                                </div>
                                <div class="fw-link">
                                    <ul>
                                        <li><a href="booking-list.html">Airline fees</a></li>
                                        <li><a href="booking-list.html">Airline guides</a></li>
                                        <li><a href="booking-list.html">Airport guides</a></li>
                                        <li><a href="booking-list.html">Low fare tips</a></li>
                                        <li><a href="booking-list.html">Flights</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-4 col-sm-8">
                            <div class="footer-widget">
                                <div class="fw-title">
                                    <h4 class="title">Contacts</h4>
                                </div>
                                <div class="footer-contact">
                                    <p>21 275 Rue Lakeshore Road, Sainte-Anne-de-Bellevue, QC H9X 3L9</p>
                                    <h2 class="title"><a href="">+1 (514) 457-5036</a></h2>
                                    <a href="https://johnabbott.qc.ca/">John Abbott College</a>
                                    <form action="#">
                                        <input type="email" placeholder="Enter your email">
                                        <button type="submit"><i class="flaticon-send"></i></button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer-bottom">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-6">
                            <div class="copyright-text">
                                <p>Copyright © 2023. All Rights Reserved By <a href="https://github.com/lizhiroi/website-development-project/">Zulu</a></p>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="cart-img text-end">
                                <img src="assets/img/images/cart.png" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- footer-area-end -->
    </main>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>

</html>